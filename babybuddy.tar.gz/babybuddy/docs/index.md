# Home

A buddy for babies! Helps caregivers track sleep, feedings, diaper changes, 
tummy time and more to learn about and predict baby's needs without (*as much*)
guess work.

## Demo

A [demo of Baby Buddy](http://demo.baby-buddy.net) is available on Heroku.
The demo instance resets every hour. Login credentials are:

- Username: `admin`
- Password: `admin`
